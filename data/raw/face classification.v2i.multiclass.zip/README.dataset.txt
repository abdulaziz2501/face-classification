# face classification > 2025-08-26 10:36pm
https://universe.roboflow.com/bottle-detection-6ypuy/face-classification-vocrg

Provided by a Roboflow user
License: MIT

